# Soutak AI - conservative rules for native DeepFilterNet and Media3.
# The AAR ships its own consumer rules. Keep native JNI entry points.
-keep class com.rikorose.deepfilternet.** { *; }
-keep class com.kaleyra.noise_filter.** { *; }
-keepclassmembers class * { native <methods>; }
