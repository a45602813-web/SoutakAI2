package com.othman.soutak.audio

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import java.io.File

object AudioPlayback {
    private var player: ExoPlayer? = null

    fun play(context: Context, file: File?) {
        if (file == null || !file.exists()) return
        val p = (player ?: ExoPlayer.Builder(context.applicationContext).build().also { player = it })
        p.stop()
        p.clearMediaItems()
        p.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        p.prepare()
        p.play()
    }

    fun stop() {
        player?.stop()
    }

    fun release() {
        player?.release()
        player = null
    }
}
