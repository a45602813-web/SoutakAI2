package com.othman.soutak

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.othman.soutak.billing.BillingManager
import com.othman.soutak.audio.AudioProcessor
import com.othman.soutak.audio.AudioRecorder
import com.othman.soutak.audio.ImportAudioUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val FREE_DAILY_LIMIT = 3

 data class UiState(
    val screen: AppScreen = AppScreen.Splash,
    val original: AudioClip? = null,
    val enhancedFile: File? = null,
    val durationMs: Long = 0L,
    val isRecording: Boolean = false,
    val recordingElapsedMs: Long = 0L,
    val isProcessing: Boolean = false,
    val progress: Float = 0f,
    val errorMessage: String? = null,
    val pendingPermissionRequest: Boolean = false,
    val darkMode: Boolean = true,
    val useCountToday: Int = 0,
    val premium: Boolean = false,
    val savingName: String = "",
    val saveRequestName: String? = null,
    val purchaseRequest: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("soutak", Application.MODE_PRIVATE)
    private val recorder = AudioRecorder(application)
    private val processor = AudioProcessor(application)
    private val importer = ImportAudioUseCase(application)
    private val billing = BillingManager(application)

    private val _uiState = MutableStateFlow(
        UiState(
            darkMode = prefs.getBoolean("dark_mode", true),
            useCountToday = usageCountToday(),
            savingName = defaultName()
        )
    )
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        billing.initialize { active ->
            _uiState.value = _uiState.value.copy(premium = active)
        }
        viewModelScope.launch {
            kotlinx.coroutines.delay(950)
            _uiState.value = _uiState.value.copy(screen = AppScreen.Home)
        }
    }

    fun onRecordingPermissionResult(granted: Boolean) {
        if (!granted) {
            _uiState.value = _uiState.value.copy(
                pendingPermissionRequest = false,
                errorMessage = "لازم تسمح باستخدام الميكروفون عشان تسجل صوت."
            )
            return
        }
        _uiState.value = _uiState.value.copy(pendingPermissionRequest = false, screen = AppScreen.Record, errorMessage = null)
    }

    fun handleAction(action: AppAction) {
        when (action) {
            AppAction.GoHome -> goHome()
            AppAction.StartRecord -> startRecordFlow()
            AppAction.StartImport -> _uiState.value = _uiState.value.copy(screen = AppScreen.Import, errorMessage = null)
            is AppAction.ImportUri -> importUri(action.uri)
            AppAction.StartRecording -> startRecording()
            AppAction.StopRecording -> stopRecording()
            AppAction.RedoRecord -> {
                cleanupCurrent()
                _uiState.value = _uiState.value.copy(screen = AppScreen.Record, original = null, enhancedFile = null, errorMessage = null)
            }
            AppAction.Enhance -> enhance()
            AppAction.PlayOriginal -> AudioPlayback.play(getApplication(), _uiState.value.original?.originalFile)
            AppAction.PlayEnhanced -> AudioPlayback.play(getApplication(), _uiState.value.enhancedFile)
            AppAction.StopPlayback -> AudioPlayback.stop()
            AppAction.ContinueToSave -> _uiState.value = _uiState.value.copy(screen = AppScreen.SaveShare)
            AppAction.SaveFile -> _uiState.value = _uiState.value.copy(saveRequestName = (_uiState.value.savingName.trim().ifBlank { "soutak_enhanced" }).replace(Regex("[^A-Za-z0-9_\\- ]"), "_"))
            AppAction.ShareFile -> shareEnhanced()
            is AppAction.SetSaveName -> _uiState.value = _uiState.value.copy(savingName = action.name)
            is AppAction.SetDarkMode -> {
                prefs.edit().putBoolean("dark_mode", action.value).apply()
                _uiState.value = _uiState.value.copy(darkMode = action.value)
            }
            AppAction.OpenSettings -> _uiState.value = _uiState.value.copy(screen = AppScreen.Settings)
            AppAction.OpenAbout -> _uiState.value = _uiState.value.copy(screen = AppScreen.About)
            AppAction.OpenPrivacy -> _uiState.value = _uiState.value.copy(screen = AppScreen.Privacy)
            AppAction.OpenTerms -> _uiState.value = _uiState.value.copy(screen = AppScreen.Terms)
            AppAction.BuyPremium -> _uiState.value = _uiState.value.copy(purchaseRequest = true)
            AppAction.ManageSubscription -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/account/subscriptions"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                getApplication<Application>().startActivity(intent)
            }
            AppAction.DismissError -> _uiState.value = _uiState.value.copy(errorMessage = null)
            AppAction.CancelProcessing -> {
                processor.cancel()
                _uiState.value = _uiState.value.copy(isProcessing = false, screen = AppScreen.Preview)
            }
        }
    }

    private fun startRecordFlow() {
        val context = getApplication<Application>()
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            _uiState.value = _uiState.value.copy(screen = AppScreen.Record, errorMessage = null)
        } else {
            _uiState.value = _uiState.value.copy(pendingPermissionRequest = true, errorMessage = null)
        }
    }

    private fun startRecording() {
        if (_uiState.value.isRecording) return
        viewModelScope.launch {
            try {
                recorder.start { elapsed ->
                    _uiState.value = _uiState.value.copy(recordingElapsedMs = elapsed, isRecording = true)
                }
                _uiState.value = _uiState.value.copy(isRecording = true, recordingElapsedMs = 0L, errorMessage = null)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "ما قدرت أبدأ التسجيل: ${e.message ?: "خطأ غير معروف"}")
            }
        }
    }

    private fun stopRecording() {
        viewModelScope.launch {
            try {
                val file = recorder.stop() ?: throw IllegalStateException("لم يتم إنشاء الملف")
                val duration = recorder.lastDurationMs
                setOriginal(file, duration)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isRecording = false, errorMessage = "حصلت مشكلة أثناء حفظ التسجيل.")
            }
        }
    }

    private fun importUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(screen = AppScreen.Processing, isProcessing = true, progress = 0f, errorMessage = null)
            try {
                val decoded = importer.decode(uri)
                val file = importer.writeWav(decoded.pcm)
                setOriginal(file, decoded.durationMs)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(screen = AppScreen.Import, isProcessing = false, errorMessage = e.message ?: "الملف غير مدعوم على هذا الهاتف.")
            }
        }
    }

    private fun setOriginal(file: File, duration: Long) {
        _uiState.value = _uiState.value.copy(
            screen = AppScreen.Preview,
            original = AudioClip(file, duration, file.nameWithoutExtension),
            durationMs = duration,
            isRecording = false,
            isProcessing = false,
            progress = 0f,
            enhancedFile = null,
            savingName = file.nameWithoutExtension
        )
    }

    private fun enhance() {
        val clip = _uiState.value.original ?: return
        val state = _uiState.value
        if (!state.premium && usageCountToday() >= FREE_DAILY_LIMIT) {
            _uiState.value = state.copy(errorMessage = "استهلكت الحد المجاني اليومي (3 تحسينات). تقدر تكمل مع Premium.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(screen = AppScreen.Processing, isProcessing = true, progress = 0f, errorMessage = null)
            try {
                val output = processor.enhance(clip.originalFile) { p ->
                    _uiState.value = _uiState.value.copy(progress = p.coerceIn(0f, 1f))
                }
                if (!state.premium) incrementUsage()
                _uiState.value = _uiState.value.copy(
                    screen = AppScreen.Comparison,
                    isProcessing = false,
                    enhancedFile = output,
                    progress = 1f,
                    savingName = clip.displayName + "_enhanced"
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                _uiState.value = _uiState.value.copy(screen = AppScreen.Preview, isProcessing = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(screen = AppScreen.Preview, isProcessing = false, errorMessage = e.message ?: "فشل تحسين الصوت.")
            }
        }
    }

    fun clearSaveRequest() { _uiState.value = _uiState.value.copy(saveRequestName = null) }

    fun launchPremiumPurchase(activity: Activity) {
        val result = billing.launchPurchase(activity)
        if (result == null || result.responseCode != com.android.billingclient.api.BillingClient.BillingResponseCode.OK) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "تعذر فتح صفحة الاشتراك حاليًا. تأكد من وجود Google Play وتسجيل الدخول بالحساب الصحيح."
            )
        }
    }

    fun clearPurchaseRequest() {
        _uiState.value = _uiState.value.copy(purchaseRequest = false)
    }

    fun onActivityResultSave(uri: Uri) {
        val source = _uiState.value.enhancedFile ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                    source.inputStream().use { input -> input.copyTo(out) }
                } ?: throw IllegalStateException("تعذر فتح مكان الحفظ")
            }.onSuccess {
                _uiState.value = _uiState.value.copy(saveRequestName = null, screen = AppScreen.SaveShare, errorMessage = null)
            }.onFailure {
                _uiState.value = _uiState.value.copy(errorMessage = "تعذر حفظ الملف.")
            }
        }
    }

    private fun shareEnhanced() {
        val file = _uiState.value.enhancedFile ?: return
        val sharedDir = File(getApplication<Application>().cacheDir, "shared").apply { mkdirs() }
        val shareFile = File(sharedDir, "${_uiState.value.savingName.ifBlank { "soutak_enhanced" }.replace(Regex("[^A-Za-z0-9_\\- ]"), "_")}.wav")
        file.copyTo(shareFile, overwrite = true)
        val context = getApplication<Application>()
        val uri = FileProvider.getUriForFile(context, "com.othman.soutak.fileprovider", shareFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(Intent.createChooser(intent, "مشاركة الصوت المحسن").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun goHome() {
        AudioPlayback.stop()
        _uiState.value = _uiState.value.copy(screen = AppScreen.Home, errorMessage = null)
    }

    private fun cleanupCurrent() {
        AudioPlayback.stop()
        _uiState.value.original?.originalFile?.delete()
        _uiState.value.enhancedFile?.delete()
    }

    private fun usageCountToday(): Int {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (prefs.getString("usage_day", "") != day) {
            prefs.edit().putString("usage_day", day).putInt("usage_count", 0).apply()
            return 0
        }
        return prefs.getInt("usage_count", 0)
    }

    private fun incrementUsage() {
        val current = usageCountToday() + 1
        prefs.edit().putInt("usage_count", current).apply()
        _uiState.value = _uiState.value.copy(useCountToday = current)
    }

    private fun defaultName(): String = "soutak_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}"

    override fun onCleared() {
        recorder.release()
        processor.release()
        billing.release()
        AudioPlayback.release()
        super.onCleared()
    }

    companion object {
        fun factory(app: Application): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(app) as T
        }
    }
}

sealed interface AppAction {
    data object GoHome : AppAction
    data object StartRecord : AppAction
    data object StartImport : AppAction
    data class ImportUri(val uri: Uri) : AppAction
    data object StartRecording : AppAction
    data object StopRecording : AppAction
    data object RedoRecord : AppAction
    data object Enhance : AppAction
    data object PlayOriginal : AppAction
    data object PlayEnhanced : AppAction
    data object StopPlayback : AppAction
    data object ContinueToSave : AppAction
    data object SaveFile : AppAction
    data object ShareFile : AppAction
    data class SetSaveName(val name: String) : AppAction
    data class SetDarkMode(val value: Boolean) : AppAction
    data object OpenSettings : AppAction
    data object OpenAbout : AppAction
    data object OpenPrivacy : AppAction
    data object OpenTerms : AppAction
    data object BuyPremium : AppAction
    data object ManageSubscription : AppAction
    data object DismissError : AppAction
    data object CancelProcessing : AppAction
}
