package com.othman.soutak

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Teal = Color(0xFF10A89A)
private val Gold = Color(0xFFD3A74A)
private val Ink = Color(0xFF0B1417)
private val CardDark = Color(0xFF111E22)
private val Muted = Color(0xFF9EB0B4)

@Composable
fun SoutakTheme(darkMode: Boolean, content: @Composable () -> Unit) {
    val scheme = if (darkMode) androidx.compose.material3.darkColorScheme(
        primary = Teal,
        secondary = Gold,
        background = Ink,
        surface = CardDark,
        onBackground = Color(0xFFF3F6F6),
        onSurface = Color(0xFFF3F6F6)
    ) else androidx.compose.material3.lightColorScheme(
        primary = Color(0xFF00796F),
        secondary = Color(0xFF8C6400)
    )
    MaterialTheme(colorScheme = scheme, typography = MaterialTheme.typography, content = content)
}

@Composable
fun SoutakAppScreen(
    state: UiState,
    screen: AppScreen,
    onAction: (AppAction) -> Unit,
    onSaveResult: (Uri) -> Unit,
    onClearSave: () -> Unit
) {
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onAction(AppAction.ImportUri(uri))
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) onSaveResult(uri) else onClearSave()
    }
    LaunchedEffect(state.saveRequestName) {
        val name = state.saveRequestName
        if (!name.isNullOrBlank()) saveLauncher.launch("$name.wav")
    }

    when (screen) {
        AppScreen.Splash -> SplashScreen()
        AppScreen.Home -> HomeScreen(state, onAction)
        AppScreen.Record -> RecordScreen(state, onAction)
        AppScreen.Import -> ImportScreen(state, onAction, importLauncher)
        AppScreen.Preview -> PreviewScreen(state, onAction)
        AppScreen.Processing -> ProcessingScreen(state, onAction)
        AppScreen.Comparison -> ComparisonScreen(state, onAction)
        AppScreen.SaveShare -> SaveShareScreen(state, onAction)
        AppScreen.Settings -> SettingsScreen(state, onAction)
        AppScreen.About -> InfoScreen(title = "عن Soutak AI", body = ABOUT_TEXT, onBack = { onAction(AppAction.OpenSettings) })
        AppScreen.Privacy -> InfoScreen(title = "سياسة الخصوصية", body = PRIVACY_TEXT, onBack = { onAction(AppAction.OpenSettings) })
        AppScreen.Terms -> InfoScreen(title = "شروط الاستخدام", body = TERMS_TEXT, onBack = { onAction(AppAction.OpenSettings) })
    }

    state.errorMessage?.let { message ->
        ErrorBanner(message = message, onDismiss = { onAction(AppAction.DismissError) })
    }
}

@Composable
private fun AppContainer(content: @Composable () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
}

@Composable
private fun SplashScreen() {
    AppContainer {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier.size(96.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Teal, Color(0xFF0E6F67)))),
                contentAlignment = Alignment.Center
            ) { Text("S", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            Spacer(Modifier.height(18.dp))
            Text("Soutak AI", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("صوتك، لكن أنقى", color = Muted)
        }
    }
}

@Composable
private fun HomeScreen(state: UiState, onAction: (AppAction) -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { onAction(AppAction.OpenSettings) }) { Text("الإعدادات") }
            }
            Spacer(Modifier.height(18.dp))
            Text("حسّن صوتك", fontSize = 36.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text("بالذكاء الاصطناعي", fontSize = 27.sp, fontWeight = FontWeight.SemiBold, color = Teal, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Text("تنظيف حقيقي للصوت من الضوضاء مع الحفاظ على طبيعة صوتك.", color = Muted, textAlign = TextAlign.Center, lineHeight = 23.sp)
            Spacer(Modifier.height(34.dp))
            PrimaryAction("🎙️  تسجيل صوت جديد", Modifier.fillMaxWidth().height(64.dp)) { onAction(AppAction.StartRecord) }
            Spacer(Modifier.height(14.dp))
            SecondaryAction("📁  اختيار تسجيل من الهاتف", Modifier.fillMaxWidth().height(60.dp)) { onAction(AppAction.StartImport) }
            Spacer(Modifier.height(28.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("كيف يعمل؟", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("سجّل أو اختر ملفًا → معالجة AI على الجهاز → قارن الأصل بالمحسّن → احفظ أو شارك.", color = Muted, lineHeight = 21.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("${state.useCountToday}/3 تحسينات مجانية اليوم", color = Gold, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("لا يوجد رفع للتسجيلات إلى الخادم في إصدار MVP.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun RecordScreen(state: UiState, onAction: (AppAction) -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            ScreenHeader("تسجيل صوت", onBack = { onAction(AppAction.GoHome) })
            Spacer(Modifier.height(36.dp))
            Text(if (state.isRecording) "جاري التسجيل…" else "اضغط للبدء", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))
            Text(formatDuration(state.recordingElapsedMs), fontSize = 42.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(42.dp))
            Box(
                modifier = Modifier.size(150.dp).clip(CircleShape).background(if (state.isRecording) Color(0xFFB84A4A) else Teal).clickable {
                    onAction(if (state.isRecording) AppAction.StopRecording else AppAction.StartRecording)
                },
                contentAlignment = Alignment.Center
            ) { Text(if (state.isRecording) "إيقاف" else "تسجيل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp) }
            Spacer(Modifier.height(32.dp))
            Text("يفضّل التسجيل في مكان هادئ وبعيدًا عن السماعة الخارجية.", color = Muted, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ImportScreen(state: UiState, onAction: (AppAction) -> Unit, launcher: androidx.activity.result.ActivityResultLauncher<Array<String>>) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            ScreenHeader("اختيار تسجيل", onBack = { onAction(AppAction.GoHome) })
            Spacer(Modifier.height(54.dp))
            Text("اختار أي ملف صوتي يدعمه جهازك", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("مثل WAV وMP3 وM4A وغيرها حسب دعم Android على هاتفك.", color = Muted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(32.dp))
            PrimaryAction("فتح الملفات", Modifier.fillMaxWidth().height(62.dp)) { launcher.launch(arrayOf("audio/*")) }
            Spacer(Modifier.height(20.dp))
            Text("Soutak يحول الصوت داخليًا إلى 48kHz mono قبل المعالجة.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            if (state.isProcessing) Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun PreviewScreen(state: UiState, onAction: (AppAction) -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp)) {
            ScreenHeader("مراجعة التسجيل", onBack = { onAction(AppAction.GoHome) })
            Spacer(Modifier.height(26.dp))
            AudioInfoCard(name = state.original?.displayName ?: "تسجيل", durationMs = state.durationMs)
            Spacer(Modifier.height(18.dp))
            SecondaryAction("▶  تشغيل الصوت الأصلي", Modifier.fillMaxWidth().height(56.dp)) { onAction(AppAction.PlayOriginal) }
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = { onAction(AppAction.StopPlayback) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("إيقاف التشغيل") }
            Spacer(Modifier.height(24.dp))
            PrimaryAction("✨  تحسين الصوت", Modifier.fillMaxWidth().height(64.dp)) { onAction(AppAction.Enhance) }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { onAction(AppAction.RedoRecord) }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("إعادة اختيار / تسجيل") }
            Spacer(Modifier.weight(1f))
            Text("المعالجة AI تتم على الجهاز ولا تحتاج إنترنت.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ProcessingScreen(state: UiState, onAction: (AppAction) -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            CircularProgressIndicator(progress = { state.progress.coerceIn(0f, 1f) }, strokeWidth = 6.dp, color = Teal, modifier = Modifier.size(92.dp))
            Spacer(Modifier.height(24.dp))
            Text("جاري تنظيف وتحسين الصوت", fontSize = 23.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("محرك DeepFilterNet يعمل محليًا على جهازك.", color = Muted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(15.dp))
            Text("${(state.progress * 100).toInt()}%", color = Gold, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(28.dp))
            TextButton(onClick = { onAction(AppAction.CancelProcessing) }) { Text("إلغاء") }
        }
    }
}

@Composable
private fun ComparisonScreen(state: UiState, onAction: (AppAction) -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp)) {
            ScreenHeader("قبل / بعد", onBack = { onAction(AppAction.GoHome) })
            Spacer(Modifier.height(20.dp))
            Text("اسمع الفرق بنفسك", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            CompareCard("قبل", "التسجيل الأصلي", { onAction(AppAction.PlayOriginal) })
            Spacer(Modifier.height(12.dp))
            CompareCard("بعد", "الصوت المحسن", { onAction(AppAction.PlayEnhanced) }, highlight = true)
            Spacer(Modifier.height(12.dp))
            Text("المدة: ${formatDuration(state.durationMs)}", color = Muted)
            Spacer(Modifier.weight(1f))
            PrimaryAction("حفظ ومشاركة", Modifier.fillMaxWidth().height(62.dp)) { onAction(AppAction.ContinueToSave) }
        }
    }
}

@Composable
private fun SaveShareScreen(state: UiState, onAction: (AppAction) -> Unit) {
    var name by remember(state.savingName) { mutableStateOf(state.savingName) }
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp)) {
            ScreenHeader("حفظ ومشاركة", onBack = { onAction(AppAction.GoHome) })
            Spacer(Modifier.height(26.dp))
            Text("الملف المحسن جاهز", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("WAV 48kHz • Mono • 16-bit", color = Muted)
            Spacer(Modifier.height(22.dp))
            OutlinedTextField(value = name, onValueChange = { name = it; onAction(AppAction.SetSaveName(it)) }, label = { Text("اسم الملف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            PrimaryAction("💾  حفظ على الهاتف", Modifier.fillMaxWidth().height(58.dp)) { onAction(AppAction.SaveFile) }
            Spacer(Modifier.height(12.dp))
            SecondaryAction("↗  مشاركة مباشرة", Modifier.fillMaxWidth().height(58.dp)) { onAction(AppAction.ShareFile) }
            Spacer(Modifier.weight(1f))
            Text("يمكنك مشاركة الملف عبر WhatsApp أو Telegram أو أي تطبيق يدعم مشاركة الصوت.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SettingsScreen(state: UiState, onAction: (AppAction) -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp)) {
            ScreenHeader("الإعدادات", onBack = { onAction(AppAction.GoHome) })
            Spacer(Modifier.height(18.dp))
            SettingsRow(title = "الوضع الداكن", subtitle = "مظهر هادئ ومناسب للاستخدام الطويل") {
                Switch(checked = state.darkMode, onCheckedChange = { onAction(AppAction.SetDarkMode(it)) })
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Premium", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(if (state.premium) "اشتراكك مفعل." else "المجاني: 3 تحسينات يوميًا.", color = Muted)
                    Spacer(Modifier.height(14.dp))
                    if (state.premium) SecondaryAction("إدارة الاشتراك", Modifier.fillMaxWidth().height(50.dp)) { onAction(AppAction.ManageSubscription) }
                    else PrimaryAction("ترقية إلى Premium", Modifier.fillMaxWidth().height(50.dp)) { onAction(AppAction.BuyPremium) }
                }
            }
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = { onAction(AppAction.OpenAbout) }) { Text("عن التطبيق") }
            TextButton(onClick = { onAction(AppAction.OpenPrivacy) }) { Text("سياسة الخصوصية") }
            TextButton(onClick = { onAction(AppAction.OpenTerms) }) { Text("شروط الاستخدام") }
        }
    }
}

@Composable
private fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    AppContainer {
        Column(Modifier.fillMaxSize().padding(22.dp)) {
            ScreenHeader(title, onBack)
            Spacer(Modifier.height(14.dp))
            LazyColumn { item { Text(body, color = Muted, lineHeight = 24.sp) } }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("←") }
        Spacer(Modifier.width(4.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AudioInfoCard(name: String, durationMs: Long) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(7.dp))
            Text(formatDuration(durationMs), color = Gold)
        }
    }
}

@Composable
private fun CompareCard(label: String, subtitle: String, onPlay: () -> Unit, highlight: Boolean = false) {
    Card(colors = CardDefaults.cardColors(containerColor = if (highlight) Color(0xFF132A29) else MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().border(if (highlight) 1.dp else 0.dp, Teal, RoundedCornerShape(22.dp))) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(if (highlight) Teal else Color(0xFF304145)), contentAlignment = Alignment.Center) { Text("▶", color = Color.White) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(label, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 13.sp) }
            TextButton(onClick = onPlay) { Text("تشغيل") }
        }
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) }
            trailing()
        }
    }
}

@Composable
private fun PrimaryAction(text: String, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun SecondaryAction(text: String, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp)) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun ErrorBanner(message: String, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.BottomCenter) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1F22)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(message, Modifier.weight(1f), color = Color(0xFFFFD9D9))
                TextButton(onClick = onDismiss) { Text("إغلاق") }
            }
        }
    }
}

private fun formatDuration(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

private const val ABOUT_TEXT = """
Soutak AI هو تطبيق لتحسين التسجيلات الصوتية باستخدام نموذج DeepFilterNet العصبي على الجهاز.

الإصدار الأول يركز على إزالة الضوضاء وتحسين وضوح الكلام وتوحيد مستوى الصوت بعد المعالجة. لا يحوّل صوتك إلى صوت شخص آخر، ولا ينفذ تقليدًا لأصوات أشخاص حقيقيين.

ملاحظة مهمة: محرك الذكاء الاصطناعي المستخدم هنا مخصص أساسًا لتحسين الكلام وتقليل الضوضاء. لا نعد بإزالة صدى الغرفة بشكل كامل أو بتحويل الاستوديو إلى تسجيل احترافي في كل بيئة.
"""

private const val PRIVACY_TEXT = """
Soutak AI في إصدار MVP يعالج الصوت محليًا على جهازك. لا يملك التطبيق صلاحية الإنترنت في بنية هذا الإصدار، ولا يرفع التسجيلات إلى خادم لمعالجة الصوت.

الملفات المؤقتة تستخدم فقط لإتمام المعالجة والتشغيل والمشاركة، ويمكن حذفها عند الحاجة. عداد الاستخدام اليومي وتفضيل المظهر محفوظان محليًا.

عند إضافة خدمات مستقبلية مثل API أو Analytics، يجب تحديث سياسة الخصوصية وإفصاحات Google Play قبل تفعيلها.
"""

private const val TERMS_TEXT = """
باستخدام Soutak AI أنت مسؤول عن الملفات التي تستوردها وعن حقك في استخدامها ومشاركتها. التطبيق لا يضمن نتيجة متساوية لكل نوع من التسجيلات أو كل جهاز.

لا تستخدم التطبيق لتقليد هوية أو صوت شخص حقيقي من دون إذنه. ميزات Voice Effects المستقبلية يجب أن تلتزم بالقوانين وسياسات المنصات.

الميزات المدفوعة، عند تفعيلها، تخضع لشروط Google Play والأسعار والشروط التي تظهر للمستخدم وقت الشراء.
"""
