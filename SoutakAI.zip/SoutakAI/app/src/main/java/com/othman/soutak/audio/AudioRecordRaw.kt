package com.othman.soutak.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class AudioRecorder(private val context: android.content.Context) {
    private var recorder: AudioRecord? = null
    private var job: Job? = null
    private var outputFile: File? = null
    private val running = AtomicBoolean(false)
    private var startTime = 0L
    var lastDurationMs: Long = 0L
        private set

    fun start(onElapsed: (Long) -> Unit) {
        if (running.get()) return
        val sampleRate = 48_000
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minBuffer > 0) { "الميكروفون لا يدعم التسجيل المطلوب على هذا الجهاز." }
        val bufferSize = maxOf(minBuffer * 2, 4096)
        val format = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val ar = try {
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.UNPROCESSED).setAudioFormat(format).setBufferSizeInBytes(bufferSize).build()
            } else null
        } catch (_: Throwable) { null } ?: AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .build()
        check(ar.state == AudioRecord.STATE_INITIALIZED) { "تعذر تهيئة الميكروفون." }
        val dir = File(context.cacheDir, "recordings").apply { mkdirs() }
        val file = File(dir, "record_${System.currentTimeMillis()}.wav")
        outputFile = file
        recorder = ar
        running.set(true)
        startTime = SystemClock.elapsedRealtime()
        ar.startRecording()
        job = CoroutineScope(Dispatchers.IO).launch {
            val pcm = ShortArray(bufferSize / 2)
            val samples = java.io.ByteArrayOutputStream()
            try {
                while (running.get()) {
                    val n = ar.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                    if (n > 0) {
                        val bytes = ByteArray(n * 2)
                        var p = 0
                        for (i in 0 until n) {
                            val s = pcm[i].toInt()
                            bytes[p++] = (s and 0xFF).toByte()
                            bytes[p++] = ((s ushr 8) and 0xFF).toByte()
                        }
                        samples.write(bytes)
                        onElapsed(SystemClock.elapsedRealtime() - startTime)
                    } else if (n < 0) {
                        throw IllegalStateException("قراءة الميكروفون فشلت.")
                    }
                }
                val raw = samples.toByteArray()
                val out = ShortArray(raw.size / 2)
                var p = 0
                for (i in out.indices) {
                    out[i] = (((raw[p].toInt() and 0xFF) or (raw[p + 1].toInt() shl 8))).toShort()
                    p += 2
                }
                WavFile.write(file, out)
            } finally {
                runCatching { ar.stop() }
                ar.release()
                recorder = null
            }
        }
    }

    suspend fun stop(): File? {
        if (!running.get()) return outputFile
        running.set(false)
        recorder?.let { runCatching { it.stop() } }
        job?.join()
        job = null
        lastDurationMs = ((outputFile?.length()?.coerceAtLeast(44L)?.minus(44L)?.div(2L) ?: 0L) * 1000L) / 48_000L
        return outputFile
    }

    fun release() {
        running.set(false)
        recorder?.let { runCatching { it.stop() }; runCatching { it.release() } }
        recorder = null
        job?.cancel()
        job = null
    }
}
