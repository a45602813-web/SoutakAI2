package com.othman.soutak

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel = viewModel(factory = MainViewModel.factory(application))
            val state by vm.uiState.collectAsStateCompat()
            var permissionRequested by remember { mutableStateOf(false) }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { granted ->
                vm.onRecordingPermissionResult(granted)
            }

            LaunchedEffect(state.purchaseRequest) {
                if (state.purchaseRequest) {
                    vm.launchPremiumPurchase(this@MainActivity)
                    vm.clearPurchaseRequest()
                }
            }

            LaunchedEffect(state.pendingPermissionRequest) {
                if (state.pendingPermissionRequest && !permissionRequested) {
                    permissionRequested = true
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else if (!state.pendingPermissionRequest) {
                    permissionRequested = false
                }
            }

            SoutakTheme(darkMode = state.darkMode) {
                Box(Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = state.screen,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screen_transition"
                    ) { screen ->
                        SoutakAppScreen(
                            state = state,
                            screen = screen,
                            onAction = vm::handleAction,
                            onSaveResult = vm::onActivityResultSave,
                            onClearSave = vm::clearSaveRequest
                        )
                    }
                }
            }
        }
    }
}
