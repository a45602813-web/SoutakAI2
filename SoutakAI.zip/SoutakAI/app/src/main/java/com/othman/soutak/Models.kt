package com.othman.soutak

import java.io.File

enum class AppScreen {
    Splash, Home, Record, Import, Preview, Processing, Comparison, SaveShare, Settings, About, Privacy, Terms
}

data class AudioClip(
    val originalFile: File,
    val durationMs: Long,
    val displayName: String
)
