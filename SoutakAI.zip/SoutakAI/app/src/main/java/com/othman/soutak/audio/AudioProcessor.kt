package com.othman.soutak.audio

import android.content.Context
import com.rikorose.deepfilternet.NativeDeepFilterNet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AudioProcessor(private val context: Context) {
    @Volatile private var cancelled = false
    private var active: NativeDeepFilterNet? = null

    suspend fun enhance(inputWav: File, onProgress: (Float) -> Unit): File = withContext(Dispatchers.Default) {
        cancelled = false
        val pcm = WavFile.readMono16(inputWav)
        val samples = AudioResampler.resample(pcm.samples, pcm.sampleRate, 48_000)
        val model = NativeDeepFilterNet(context.applicationContext).also { active = it }
        model.setAttenuationLimit(30f)
        val frameLengthBytes = model.frameLength.toInt()
        require(frameLengthBytes >= 2 && frameLengthBytes % 2 == 0) { "محرك AI أعاد حجم إطار غير صالح." }
        val frameSamples = frameLengthBytes / 2
        val paddedFrames = ((samples.size + frameSamples - 1) / frameSamples).coerceAtLeast(1)
        val padded = ShortArray(paddedFrames * frameSamples)
        samples.copyInto(padded)
        val out = ShortArray(padded.size)
        val buffer = ByteBuffer.allocateDirect(frameLengthBytes).order(ByteOrder.LITTLE_ENDIAN)
        try {
            for (frame in 0 until paddedFrames) {
                coroutineContext.ensureActive()
                if (cancelled) throw CancellationException("تم إلغاء المعالجة")
                buffer.clear()
                for (i in 0 until frameSamples) buffer.putShort(padded[frame * frameSamples + i])
                buffer.flip()
                model.processFrame(buffer)
                buffer.rewind()
                for (i in 0 until frameSamples) out[frame * frameSamples + i] = buffer.short
                onProgress((frame + 1f) / paddedFrames)
            }
            val trimmed = out.copyOf(samples.size)
            val normalized = normalizePeak(trimmed, targetDb = -1f, maxGainDb = 6f)
            val output = File(context.cacheDir, "enhanced_${System.currentTimeMillis()}.wav")
            WavFile.write(output, normalized)
            output
        } finally {
            runCatching { model.release() }
            active = null
        }
    }

    private fun normalizePeak(input: ShortArray, targetDb: Float, maxGainDb: Float): ShortArray {
        var peak = 1
        for (s in input) peak = maxOf(peak, kotlin.math.abs(s.toInt()))
        val targetLinear = Math.pow(10.0, targetDb / 20.0)
        val desired = targetLinear * 32767.0 / peak.toDouble()
        val maxGain = Math.pow(10.0, maxGainDb / 20.0)
        val gain = desired.coerceAtMost(maxGain)
        if (gain <= 1.001) return input
        return ShortArray(input.size) { i -> (input[i].toInt() * gain).toInt().coerceIn(-32768, 32767).toShort() }
    }

    fun cancel() { cancelled = true }
    fun release() { cancelled = true }
}
