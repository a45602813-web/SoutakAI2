package com.othman.soutak.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ImportAudioUseCase(private val context: Context) {
    data class Decoded(val pcm: ShortArray, val durationMs: Long)

    suspend fun decode(uri: Uri): Decoded = withContext(Dispatchers.IO) {
        val scheme = uri.scheme?.lowercase()
        if (scheme == "file") return@withContext decodeFile(uri.path?.let(::File) ?: error("ملف غير صالح"))
        val type = context.contentResolver.getType(uri)?.lowercase().orEmpty()
        if (type == "audio/wav" || type == "audio/x-wav") {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر قراءة الملف.")
            val tmp = File(context.cacheDir, "import_${System.currentTimeMillis()}.wav")
            return@withContext try {
                tmp.writeBytes(bytes)
                decodeFile(tmp)
            } finally {
                tmp.delete()
            }
        }
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error("تعذر فتح الملف.")
        pfd.use {
            decodeWithMediaCodec(it.fileDescriptor)
        }
    }

    fun writeWav(samples: ShortArray): File {
        val file = File(context.cacheDir, "normalized_${System.currentTimeMillis()}.wav")
        WavFile.write(file, samples)
        return file
    }

    private fun decodeFile(file: File): Decoded {
        val wav = WavFile.readMono16(file)
        val resampled = AudioResampler.resample(wav.samples, wav.sampleRate, 48_000)
        return Decoded(resampled, resampled.size * 1000L / 48_000L)
    }

    private fun decodeWithMediaCodec(fd: java.io.FileDescriptor): Decoded {
        val extractor = MediaExtractor()
        extractor.setDataSource(fd)
        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                trackIndex = i; format = f; break
            }
        }
        require(trackIndex >= 0 && format != null) { "لم أجد مسارًا صوتيًا صالحًا في الملف." }
        extractor.selectTrack(trackIndex)
        val mime = format!!.getString(MediaFormat.KEY_MIME) ?: error("ترميز صوت غير معروف")
        val decoder = MediaCodec.createDecoderByType(mime)
        val sampleRate = format!!.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channels = format!!.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val pcmEncoding = if (android.os.Build.VERSION.SDK_INT >= 24 && format!!.containsKey(MediaFormat.KEY_PCM_ENCODING)) format!!.getInteger(MediaFormat.KEY_PCM_ENCODING) else android.media.AudioFormat.ENCODING_PCM_16BIT
        decoder.configure(format, null, null, 0)
        decoder.start()
        val chunks = java.io.ByteArrayOutputStream()
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val input = decoder.getInputBuffer(inIndex)!!
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                when {
                    outIndex >= 0 -> {
                        val out = decoder.getOutputBuffer(outIndex)
                        if (out != null && info.size > 0) {
                            out.position(info.offset); out.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size)
                            out.get(bytes)
                            chunks.write(bytes)
                        }
                        decoder.releaseOutputBuffer(outIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        // Output format may expose the PCM encoding/channel layout; the input format is enough for common Android decoders.
                    }
                }
            }
        } finally {
            runCatching { decoder.stop() }
            decoder.release()
            extractor.release()
        }
        val raw = chunks.toByteArray()
        val mono = pcmToMono(raw, channels, pcmEncoding)
        val resampled = AudioResampler.resample(mono, sampleRate, 48_000)
        return Decoded(resampled, resampled.size * 1000L / 48_000L)
    }

    private fun pcmToMono(raw: ByteArray, channels: Int, encoding: Int): ShortArray {
        if (encoding == android.media.AudioFormat.ENCODING_PCM_FLOAT) {
            val bytesPerSample = 4
            val frames = raw.size / (channels * bytesPerSample)
            val mono = ShortArray(frames)
            var p = 0
            for (i in 0 until frames) {
                var sum = 0.0
                repeat(channels) {
                    val b = raw[p].toInt() and 0xFF or ((raw[p+1].toInt() and 0xFF) shl 8) or ((raw[p+2].toInt() and 0xFF) shl 16) or (raw[p+3].toInt() shl 24)
                    sum += Float.fromBits(b).toDouble()
                    p += 4
                }
                mono[i] = (sum / channels.coerceAtLeast(1) * 32767.0).toInt().coerceIn(-32768, 32767).toShort()
            }
            return mono
        }
        require(encoding == android.media.AudioFormat.ENCODING_PCM_16BIT) { "عمق PCM غير مدعوم على هذا الجهاز." }
        val frames = raw.size / (channels * 2)
        val mono = ShortArray(frames)
        var p = 0
        for (i in 0 until frames) {
            var sum = 0L
            repeat(channels) {
                sum += ((raw[p].toInt() and 0xFF) or (raw[p+1].toInt() shl 8)).toShort().toInt()
                p += 2
            }
            mono[i] = (sum / channels.coerceAtLeast(1)).toInt().coerceIn(-32768, 32767).toShort()
        }
        return mono
    }
}

object AudioResampler {
    fun resample(input: ShortArray, fromRate: Int, toRate: Int): ShortArray {
        if (input.isEmpty() || fromRate == toRate) return input
        val outLength = (input.size.toLong() * toRate / fromRate).coerceAtMost(Int.MAX_VALUE).toInt()
        val out = ShortArray(outLength)
        val ratio = fromRate.toDouble() / toRate.toDouble()
        for (i in out.indices) {
            val sourcePos = i * ratio
            val idx = sourcePos.toInt().coerceAtMost(input.lastIndex)
            val frac = sourcePos - idx
            val a = input[idx].toInt()
            val b = input[(idx + 1).coerceAtMost(input.lastIndex)].toInt()
            out[i] = (a + (b - a) * frac).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }
}
