package com.othman.soutak.audio

import java.io.BufferedInputStream
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.max

object WavFile {
    data class Pcm(val samples: ShortArray, val sampleRate: Int = 48_000, val channels: Int = 1)

    fun write(file: File, samples: ShortArray, sampleRate: Int = 48_000, channels: Int = 1) {
        file.parentFile?.mkdirs()
        val dataSize = samples.size * 2
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(0)
            raf.writeBytes("RIFF")
            writeLeInt(raf, 36 + dataSize)
            raf.writeBytes("WAVE")
            raf.writeBytes("fmt ")
            writeLeInt(raf, 16)
            writeLeShort(raf, 1)
            writeLeShort(raf, channels)
            writeLeInt(raf, sampleRate)
            writeLeInt(raf, sampleRate * channels * 2)
            writeLeShort(raf, channels * 2)
            writeLeShort(raf, 16)
            raf.writeBytes("data")
            writeLeInt(raf, dataSize)
            val buffer = ByteArray(8192)
            var idx = 0
            var b = 0
            while (idx < samples.size) {
                val count = minOf((buffer.size / 2), samples.size - idx)
                var p = 0
                repeat(count) {
                    val s = samples[idx++] .toInt()
                    buffer[p++] = (s and 0xFF).toByte()
                    buffer[p++] = ((s ushr 8) and 0xFF).toByte()
                }
                raf.write(buffer, 0, p)
                b += p
            }
        }
    }

    fun readMono16(file: File): Pcm {
        BufferedInputStream(file.inputStream()).use { input ->
            val header = ByteArray(12)
            readFully(input, header)
            require(String(header, 0, 4, Charsets.US_ASCII) == "RIFF") { "الملف ليس WAV صالحًا." }
            require(String(header, 8, 4, Charsets.US_ASCII) == "WAVE") { "صيغة WAV غير صالحة." }

            var audioFormat = 1
            var channels = 1
            var sampleRate = 48_000
            var bits = 16
            var data: ByteArray? = null
            val chunkHeader = ByteArray(8)
            while (true) {
                val read = input.read(chunkHeader)
                if (read < 8) break
                val id = String(chunkHeader, 0, 4, Charsets.US_ASCII)
                val size = leInt(chunkHeader, 4)
                if (size < 0) break
                when (id) {
                    "fmt " -> {
                        val fmt = ByteArray(size)
                        readFully(input, fmt)
                        audioFormat = leShort(fmt, 0)
                        channels = leShort(fmt, 2)
                        sampleRate = leInt(fmt, 4)
                        bits = leShort(fmt, 14)
                    }
                    "data" -> {
                        data = ByteArray(size)
                        readFully(input, data)
                        break
                    }
                    else -> {
                        var remaining = size
                        while (remaining > 0) {
                            val skipped = input.skip(remaining.toLong()).toInt()
                            if (skipped <= 0) break
                            remaining -= skipped
                        }
                    }
                }
            }
            require(data != null) { "ملف WAV لا يحتوي على بيانات صوتية." }
            require(audioFormat == 1 || audioFormat == 3) { "ترميز WAV غير مدعوم." }
            require(bits == 16 || (audioFormat == 3 && bits == 32)) { "عمق الصوت غير مدعوم." }
            val raw = data!!
            val frames = if (audioFormat == 1) raw.size / (channels * 2) else raw.size / (channels * 4)
            val mono = ShortArray(frames)
            if (audioFormat == 1) {
                var pos = 0
                for (i in 0 until frames) {
                    var sum = 0L
                    repeat(channels) {
                        sum += ((raw[pos].toInt() and 0xFF) or (raw[pos + 1].toInt() shl 8)).toShort().toInt()
                        pos += 2
                    }
                    mono[i] = (sum / max(1, channels)).toInt().coerceIn(-32768, 32767).toShort()
                }
            } else {
                var pos = 0
                for (i in 0 until frames) {
                    var sum = 0.0
                    repeat(channels) {
                        val bitsValue = leInt(raw, pos)
                        sum += Float.fromBits(bitsValue).toDouble()
                        pos += 4
                    }
                    mono[i] = (sum / max(1, channels) * 32767.0).toInt().coerceIn(-32768, 32767).toShort()
                }
            }
            return Pcm(mono, sampleRate, 1)
        }
    }

    private fun writeLeInt(raf: RandomAccessFile, value: Int) {
        raf.write(value and 0xFF); raf.write((value ushr 8) and 0xFF); raf.write((value ushr 16) and 0xFF); raf.write((value ushr 24) and 0xFF)
    }
    private fun writeLeShort(raf: RandomAccessFile, value: Int) {
        raf.write(value and 0xFF); raf.write((value ushr 8) and 0xFF)
    }
    private fun leInt(bytes: ByteArray, o: Int): Int = (bytes[o].toInt() and 0xFF) or ((bytes[o+1].toInt() and 0xFF) shl 8) or ((bytes[o+2].toInt() and 0xFF) shl 16) or (bytes[o+3].toInt() shl 24)
    private fun leShort(bytes: ByteArray, o: Int): Int = (bytes[o].toInt() and 0xFF) or ((bytes[o+1].toInt() and 0xFF) shl 8)
    private fun readFully(input: BufferedInputStream, bytes: ByteArray) {
        var off = 0
        while (off < bytes.size) {
            val n = input.read(bytes, off, bytes.size - off)
            if (n < 0) throw IllegalStateException("ملف الصوت ناقص أو تالف.")
            off += n
        }
    }
}
