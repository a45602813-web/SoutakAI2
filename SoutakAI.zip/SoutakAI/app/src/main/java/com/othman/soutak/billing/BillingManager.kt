package com.othman.soutak.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.BillingClientStateListener

class BillingManager(private val context: Context) {
    companion object { const val PREMIUM_PRODUCT_ID = "soutak_premium_monthly" }

    private var client: BillingClient? = null
    private var premiumDetails: ProductDetails? = null
    private var premiumActive = false
    private var pendingCallback: ((Boolean) -> Unit)? = null

    fun initialize(onEntitlement: (Boolean) -> Unit) {
        pendingCallback = onEntitlement
        client = BillingClient.newBuilder(context)
            .setListener { _, purchases -> purchases?.let { handlePurchases(it) } }
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build()
        client!!.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                    queryPurchases()
                }
            }
            override fun onBillingServiceDisconnected() = Unit
        })
    }

    private fun queryProducts() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(PREMIUM_PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build())
        ).build()
        client?.queryProductDetailsAsync(params) { result, details ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) premiumDetails = details.productDetailsList.firstOrNull()
        }
    }

    private fun queryPurchases() {
        client?.queryPurchasesAsync(
            com.android.billingclient.api.QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        ) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) handlePurchases(purchases)
        }
    }

    private fun handlePurchases(purchases: List<Purchase>) {
        premiumActive = purchases.any { it.products.contains(PREMIUM_PRODUCT_ID) && it.purchaseState == Purchase.PurchaseState.PURCHASED }
        pendingCallback?.invoke(premiumActive)
        purchases.filter { it.products.contains(PREMIUM_PRODUCT_ID) && it.purchaseState == Purchase.PurchaseState.PURCHASED && !it.isAcknowledged }
            .forEach { purchase ->
                client?.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()) { }
            }
    }

    fun launchPurchase(activity: Activity): BillingResult? {
        val details = premiumDetails ?: return null
        val offer = details.subscriptionOfferDetails?.firstOrNull() ?: return null
        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).setOfferToken(offer.offerToken).build()
        val flowParams = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(productParams)).build()
        return client?.launchBillingFlow(activity, flowParams)
    }

    fun release() { client?.endConnection(); client = null }
}
