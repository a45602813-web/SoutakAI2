# Soutak AI — صوتك، لكن أنقى

Android Native MVP for on-device AI voice enhancement.

## What is implemented

- Kotlin + Jetpack Compose + Material 3 UI.
- 48 kHz mono 16-bit PCM recording with `AudioRecord`.
- Android Storage Access Framework import.
- Common audio decoding through Android `MediaExtractor` / `MediaCodec` when the device codec supports the input.
- Real on-device neural speech/noise enhancement using the DeepFilterNet Android AAR.
- Peak normalization after enhancement.
- Before/After playback with AndroidX Media3 ExoPlayer.
- Save as WAV through the system document picker.
- Android Sharesheet sharing with `FileProvider`.
- File renaming before save/share.
- Dark/light appearance.
- Local free-use counter (3 enhancements/day).
- Google Play Billing integration hook for a real subscription product; there is no fake payment screen.
- In-app About, Privacy Policy, and Terms pages.
- No `INTERNET` permission in the MVP; audio is not uploaded for processing.

## AI implementation and limits

The “AI enhancement” is real. `AudioProcessor` instantiates `NativeDeepFilterNet` and sends 48 kHz PCM frames to the neural model on-device. The chosen model is primarily a speech/noise enhancement system. This MVP therefore does not claim perfect room dereverberation, studio mastering, or voice conversion.

## Architecture

`Compose UI → MainViewModel → use-cases/services → AudioRecord / MediaCodec / DeepFilterNet / Media3 / FileProvider / BillingClient`

There is deliberately no backend in the audio path. A backend is only recommended later for server-side Play purchase verification, entitlement synchronization, analytics, remote configuration, or a future cloud enhancement model.

## Key technical choices

- AGP 9.4.0, Gradle 9.6, JDK 17, compile/target SDK 37.
- Compose BOM 2026.09.00.
- Lifecycle 2.11.0.
- Media3 ExoPlayer 1.11.1.
- DeepFilterNet Android AAR 0.0.8.
- Google Play Billing 9.1.0.

AGP 9.4.0 supports API level 37 and uses Gradle 9.6/JDK 17 in its compatibility matrix.

## Open in Android Studio

1. Install a recent Android Studio version that supports AGP 9.4.x.
2. Install JDK 17 and select it as the Gradle JDK.
3. Install Android SDK Platform 37 and the required SDK Build Tools.
4. Open the `/SoutakAI` project folder.
5. Allow Android Studio to sync and download Maven dependencies.
6. Connect an Android phone with USB debugging enabled or create an emulator.
7. Run the `app` configuration.

## APK

For a development APK: Android Studio → **Build** → **Build APK(s)**.

For a release APK: Android Studio → **Build** → **Generate Signed Bundle / APK** → APK.

## AAB for Google Play

Android Studio → **Build** → **Generate Signed Bundle / APK** → Android App Bundle → choose/create your upload key → build the release bundle.

The expected output is under:

`app/build/outputs/bundle/release/`

## Gradle wrapper

This workspace does not contain the Android SDK, Gradle executable, or outbound dependency access, so I could not generate the Gradle wrapper JAR or execute a real Gradle build here. `gradle/wrapper/gradle-wrapper.properties` is included with the pinned Gradle 9.6 distribution URL.

On a machine with Gradle 9.6 installed, from the project root run:

`gradle wrapper --gradle-version 9.6`

That generates `gradlew`, `gradlew.bat`, and the wrapper JAR locally.

After that you can use:

`./gradlew assembleDebug`

`./gradlew assembleRelease`

`./gradlew bundleRelease`

## Release signing

Do not commit keystores or passwords. Use `keystore.properties.example` as the local template. For Google Play, use Play App Signing and keep the upload key backed up securely.

## Google Play Billing

The code uses a real BillingClient flow, but the product does not exist in your Play Console until you create it. The placeholder product ID is:

`soutak_premium_monthly`

Before production: create the subscription and base plan in Play Console, then use the exact product ID in `BillingManager.kt`. For stronger production entitlement security, add a backend verifier and Real-time Developer Notifications rather than trusting only a client-side state.

## Privacy

The MVP has no Internet permission and no analytics SDK. Audio remains on-device unless the user explicitly saves/shares it. The cache is excluded from Android backup. Public web-hosted Privacy Policy and Terms templates are included under `/docs`.

## Manual checklist before publishing

1. Final brand/name clearance and package-name decision.
2. Replace placeholder support contact details in the HTML/legal copy.
3. Create the Google Play Console app.
4. Create the subscription product/base plan and configure pricing/regions/trial rules.
5. Put the production Play product ID into `BillingManager.kt`.
6. Configure release signing and Play App Signing.
7. Host `/docs/privacy-policy.html` and `/docs/terms-of-service.html` on public HTTPS URLs.
8. Complete Play Console Data Safety, content rating, app access, store listing, testing, and subscription disclosures.
9. Test real microphones, headphones, noisy rooms, long files, corrupt/unsupported files, interruptions, low storage, and permission denial.
10. Validate the enhancement model quality on representative Arabic/English speech before launch.

## What I could not execute in this environment

I could not produce a verified APK/AAB here because the build environment has no Android SDK/Gradle installation and cannot download the required Maven artifacts. I also cannot create your Google Play Console account, billing products, signing key, public legal URLs, or publish the app. Those parts are intentionally left as manual steps rather than marked as complete.

## Third-party licensing

See `THIRD_PARTY_LICENSES.md`. In particular, the AndroidDeepFilterNet 0.0.8 Maven artifact is published under Apache License 2.0. Review the exact dependency notices again when cutting the production release.
