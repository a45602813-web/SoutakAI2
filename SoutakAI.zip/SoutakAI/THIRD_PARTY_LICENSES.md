# Third-party licenses

Soutak AI uses third-party open-source components. Before a production release, keep this notice with the source and review each dependency's current license/notice.

## AndroidDeepFilterNet 0.0.8
- Artifact: `io.github.kaleyravideo:android-deepfilternet:0.0.8`
- License published in Maven metadata: Apache License 2.0.
- This component derives from the DeepFilterNet project and includes native/model assets.

## AndroidX / Jetpack Compose / Media3
- AndroidX, Jetpack Compose, and AndroidX Media3 are open-source Google/Android libraries distributed under Apache License 2.0 terms with their respective NOTICE/LICENSE files.

## Kotlin / Kotlin Coroutines
- Kotlin and kotlinx.coroutines are open-source projects distributed under Apache License 2.0 terms.

## Google Play Billing
- Google Play Billing Library is a Google Android client library. Review the current SDK terms/notices in the exact version used for the release.

Do not remove required copyright/license notices from third-party components when packaging the production app.
